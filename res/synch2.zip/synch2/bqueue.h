#ifndef BQUEUE_H
#define BQUEUE_H

#include <pthread.h>

typedef struct {
	void **data;
	unsigned max_items, count, head, tail;
	pthread_mutex_t lock;
	pthread_cond_t not_empty, not_full;
} BoundedQueue;

BoundedQueue *bqueue_create(unsigned max_items);
void bqueue_destroy(BoundedQueue *bq);
void bqueue_enqueue(BoundedQueue *bq, void *item);
void *bqueue_dequeue(BoundedQueue *bq);

#endif /* BQUEUE_H */
