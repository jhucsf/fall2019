Reference solution for CSF Fall 2019 HW2

Please do not distribute publically!
