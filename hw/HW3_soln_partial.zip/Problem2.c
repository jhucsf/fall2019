#include <stdio.h>

const char *s_ins_names[] = {
	"HLT",
	"LDA",
	"LDI",
	"STA",
	"STI",
	"ADD",
	"SUB",
	"JMP",
	"JMZ",
};

int main(void) {
	unsigned addr = 0;

	int c;
	int done = 0;
	while (!done && addr < 16) {
		c = fgetc(stdin);
		if (c == EOF) {
			done = 1;
		} else {
			int code = (c & 0xF0) >> 4;
			int data = (c & 0xF);
			const char *ins_name = (code < 9) ? s_ins_names[code] : "???";
			printf("%x: %s %x\n", addr, ins_name, data);
			addr++;
		}
	}

	return 0;
}
